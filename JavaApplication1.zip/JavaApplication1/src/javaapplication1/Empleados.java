/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author UTPL
 */
import java.util.List;

public class Empleados {
    private String nombre;
    private double salario;
    private int edad;

    public Empleados(String nombre, double salario, int edad) {
        this.nombre = nombre;
        this.salario = salario;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public int getEdad() {
        return edad;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Salario: " + salario + ", Edad: " + edad;
    }

    public static void mostrarInformacion(List<Empleados> empleados) {
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados registrados.");
        } else {
            double sumaSalarios = 0;
            for (Empleados e : empleados) {
                System.out.println(e);
                sumaSalarios += e.getSalario();
            }
            double salarioPromedio = sumaSalarios / empleados.size();
            System.out.println("Salario promedio: " + salarioPromedio);
        }
    }

    public static void CalcularSalario(List<Empleados> empleados, double porcentaje) {
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados registrados.");
        } else {
            double sumaSalarios = 0;
            for (Empleados e : empleados) {
                sumaSalarios += e.getSalario();
            }
            double salarioPromedio = sumaSalarios / empleados.size();
            for (Empleados e : empleados) {
                if (e.getSalario() < salarioPromedio) {
                    double nuevoSalario = e.getSalario() + (e.getSalario() * porcentaje / 100);
                    e.setSalario(nuevoSalario);
                    System.out.println("Nuevo salario de " + e.getNombre() + ": " + nuevoSalario);
                }
            }
        }
    }
}


    
    
    

